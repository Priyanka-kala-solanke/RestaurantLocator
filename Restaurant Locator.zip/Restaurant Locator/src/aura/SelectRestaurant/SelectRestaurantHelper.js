({
    //search for restaurant as per search term and range.
    searchForRestaurant : function(component, event, helper) {
        var buttonClicked = event.getSource().getLocalId();
        var searchTerm=component.get("v.searchTerm");
        
        
        var action = component.get("c.getRestaurants");
        if(buttonClicked=='one'){
            component.set("v.isRandom",true);
            action.setParams({ range :'One',searchTerm:searchTerm});
            
        }
        if(buttonClicked=='five'){
            if(searchTerm==null || searchTerm==undefined){
                alert('Please fill search term');
            }
            component.set("v.isRandom",false);
            action.setParams({ range :'Five',searchTerm:searchTerm });
            
        }
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                var restuarntList=response.getReturnValue();
                
                component.set("v.Restaurants",restuarntList);
                
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }else {
                        console.log("Unknown error");
                    }
                    
                }
            }
        });
        $A.enqueueAction(action);
        
    },
    
    //Process the selected Restaurants
    handleSelectedRestaurants: function(component, event, helper) {
        var selectedRestaurants = [];
        var checkvalue = component.find("checkRestuarant");
         if(checkvalue==null || checkvalue==undefined){
            alert('please select restaurant');
        }
        else{
        if(!Array.isArray(checkvalue)){
            if (checkvalue.get("v.value") == true) {
                selectedRestaurants.push(checkvalue.get("v.text"));
            }
        }else{
            for (var i = 0; i < checkvalue.length; i++) {
                if (checkvalue[i].get("v.value") == true) {
                    selectedRestaurants.push(checkvalue[i].get("v.text"));
                }
            }
        }
       

        var action=component.get("c.saveRestaurants");
        action.setParams({ restauranList :selectedRestaurants});
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                alert('Successful!');
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }else {
                        console.log("Unknown error");
                    }
                    
                }
            }
        });
        $A.enqueueAction(action);
        }
    }
    
})
({
	searchForRestaurant : function(component, event, helper) {
		helper.searchForRestaurant(component, event, helper);
	},
    
    handleSelectedRestaurants: function(component, event, helper) {
       helper.handleSelectedRestaurants(component, event, helper);
    }

})
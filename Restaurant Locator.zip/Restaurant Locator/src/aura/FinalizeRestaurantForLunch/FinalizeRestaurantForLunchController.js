({
    doInit : function(component, event, helper) {
        helper.doInit(component, event, helper);
    },
    finalizeRestaurant:function(component, event, helper) {
        helper.finalizeRestaurant(component, event, helper);
    }
    
})
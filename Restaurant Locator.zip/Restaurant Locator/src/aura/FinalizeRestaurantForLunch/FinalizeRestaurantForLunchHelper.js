({
    //Display restaurant selected by team members to respective team leads.
    doInit : function(component, event, helper) {
        var action=component.get("c.getSelectedRestaurantsbyMembers");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                var restuarntList=response.getReturnValue();
                
                component.set("v.Restaurants",restuarntList);
                
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }else {
                        console.log("Unknown error");
                    }
                    
                }
            }
        });
        $A.enqueueAction(action);
        
    },
    //update lunch venue for team.
    finalizeRestaurant:function(component, event, helper) {
        var selectedRestaurants=component.get("v.Restaurants");
        var action=component.get("c.finalizeVenue");
        action.setParams({ restauranList :selectedRestaurants});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                alert('All team members will get notified about todays venue');
                
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }else {
                        console.log("Unknown error");
                    }
                    
                }
            }
        });
        $A.enqueueAction(action);
    }
})